from django.contrib import admin
from django.urls import path, include
from polls import views  # Import views here to use address/phone

urlpatterns = [
    path("admin/", admin.site.urls),
    path("polls/", include("polls.urls")),
    path("address/", views.address),  # <== Global route
    path("phone/", views.phone),      # <== Global route
]
