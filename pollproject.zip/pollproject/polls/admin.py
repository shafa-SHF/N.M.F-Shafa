from django.contrib import admin
from .models import Settings

admin.site.register(Settings)

