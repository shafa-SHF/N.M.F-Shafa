X=input("enter the X:")
Y=input("enter the Y:")

X=bool(X)
Y=bool(Y)

print ("RESULTS: ")
print ("X and Y:", X and Y)
print ("X or Y:", X or Y)
print ("not X:",not X)
print (" X xor Y:", X!= Y)

  
