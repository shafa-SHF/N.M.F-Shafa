x="Nusa putra university"
y=2002
z=743.67
y=int(y)
z=float(z)
if isinstance(x,str) and isinstance(y,int) and isinstance(z,float):
    print ("valid input types")
else:
    print ("invalid input types")
