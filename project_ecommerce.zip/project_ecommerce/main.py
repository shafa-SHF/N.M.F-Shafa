from ecommerce.pricing import calculate_discount, calculate_tax
from ecommerce.order import generate_order_id, calculate_total

# Sample input
price = 100.0
discount_percent = 10
tax_percent = 8

# Calculations
price_after_discount = calculate_discount(price, discount_percent)
tax_amount = calculate_tax(price_after_discount, tax_percent)
total_price = calculate_total(price_after_discount, tax_amount)
order_id = generate_order_id()

# Output
print(f"Order ID: {order_id}")
print(f"Original Price: ${price:.2f}")
print(f"Price after {discount_percent}% discount: ${price_after_discount:.2f}")
print(f"Tax Amount: ${tax_amount:.2f}")
print(f"Total Price: ${total_price:.2f}")

