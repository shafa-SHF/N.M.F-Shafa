def calculate_discount(price, discount_percent):
    discount = price * (discount_percent / 100)
    return price - discount

def calculate_tax(price, tax_percent):
    tax = price * (tax_percent / 100)
    return tax
