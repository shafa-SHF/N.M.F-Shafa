import uuid

def generate_order_id():
    return str(uuid.uuid4())

def calculate_total(price_after_discount, tax_amount):
    return price_after_discount + tax_amount
